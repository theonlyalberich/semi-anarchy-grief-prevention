/*
 * This source file is part of BetterModel.
 * Copyright (c) 2026 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.bukkit.nms.v1_21_R5

import io.netty.buffer.Unpooled
import io.papermc.paper.adventure.PaperAdventure
import io.papermc.paper.configuration.GlobalConfiguration
import it.unimi.dsi.fastutil.ints.IntSet
import kr.toxicity.model.api.BetterModel
import kr.toxicity.model.api.bukkit.BetterModelBukkit
import kr.toxicity.model.api.tracker.EntityTrackerRegistry
import net.kyori.adventure.text.serializer.gson.GsonComponentSerializer
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket
import net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket
import net.minecraft.network.syncher.SynchedEntityData
import net.minecraft.network.syncher.SynchedEntityData.DataItem
import net.minecraft.network.syncher.SynchedEntityData.DataValue
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.entity.*
import net.minecraft.world.entity.ai.goal.RangedAttackGoal
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal
import net.minecraft.world.entity.ai.goal.RangedCrossbowAttackGoal
import net.minecraft.world.entity.animal.FlyingAnimal
import net.minecraft.world.entity.player.Player
import net.minecraft.world.item.ItemStack
import net.minecraft.world.phys.Vec3
import org.bukkit.Bukkit
import org.bukkit.craftbukkit.entity.CraftEntity
import org.bukkit.craftbukkit.inventory.CraftItemStack
import org.bukkit.craftbukkit.util.CraftChatMessage
import org.joml.Vector3f
import java.util.*

internal inline fun <reified T, reified R> createAdaptedFieldGetter(noinline paperGetter: (T) -> R): (T) -> R {
    return if (BetterModelBukkit.IS_PAPER) paperGetter else createAdaptedFieldGetter()
}
internal inline fun <reified T, reified R> createAdaptedFieldGetter(): (T) -> R {
    return T::class.java.declaredFields.first {
        R::class.java.isAssignableFrom(it.type)
    }.apply {
        isAccessible = true
    }.let { getter ->
        { t ->
            getter[t] as R
        }
    }
}

internal fun <H, T> dirtyChecked(hash: () -> H, function: (H) -> T, equalityChecker: (H, H) -> Boolean = { a, b -> a == b }): () -> T {
    val lock = Any()
    var h = hash()
    var value = function(h)
    return {
        val newH = hash()
        if (equalityChecker(h, newH)) value else synchronized(lock) {
            h = newH
            value = function(h)
            value
        }
    }
}

internal val CONFIG get() = BetterModel.config()
internal val EMPTY_ITEM = VanillaItemStack.EMPTY
internal fun BukkitItemStack.asVanilla() = CraftItemStack.asNMSCopy(this)
internal fun VanillaItemStack.asBukkit() = CraftItemStack.asCraftMirror(this)

internal val ONLINE_MODE by lazy(LazyThreadSafetyMode.NONE) {
    if (BetterModelBukkit.IS_PAPER) GlobalConfiguration.get().proxies.isProxyOnlineMode else Bukkit.getOnlineMode()
}

internal fun List<Int>.toIntSet(): IntSet = IntSet.of(*toIntArray())

internal fun Entity.passengerPosition(dest: Vector3f): Vector3f {
    return attachments.get(EntityAttachment.PASSENGER, 0, yRot).let { v ->
        dest.set(v.x.toFloat(), v.y.toFloat(), v.z.toFloat())
    }
}

private val DATA_ITEMS = SynchedEntityData::class.java.declaredFields.first {
    it.type.isArray
}.apply {
    isAccessible = true
}

internal fun SynchedEntityData.pack(
    clean: Boolean = false,
    itemFilter: (DataItem<*>) -> Boolean = { true },
    valueFilter: (DataValue<*>) -> Boolean = { true },
    required: (List<Pair<DataItem<*>, DataValue<*>>>) -> Boolean = { it.isNotEmpty() }
): List<DataValue<*>>? = (DATA_ITEMS[this] as Array<*>)
    .mapNotNull map@ {
        val item = (it as? DataItem<*>)?.takeIf(itemFilter) ?: return@map null
        val value = item.value().takeIf(valueFilter) ?: return@map null
        item to value
    }
    .takeIf(required)
    ?.map {
        if (clean) it.first.isDirty = false
        it.second
    }

internal fun Entity.isWalking(): Boolean {
    return controllingPassenger?.isWalking() ?: when (this) {
        is Mob -> navigation.isInProgress || goalSelector.availableGoals.any {
            it.isRunning && when (it.goal) {
                is RangedAttackGoal, is RangedCrossbowAttackGoal<*>, is RangedBowAttackGoal<*> -> true
                else -> false
            }
        }
        is ServerPlayer -> xMovement() != 0F || zMovement() != 0F
        else -> false
    }
}

internal fun ServerPlayer.xMovement(): Float {
    val leftMovement: Boolean = lastClientInput.left()
    val rightMovement: Boolean = lastClientInput.right()
    return if (leftMovement == rightMovement) 0F else if (leftMovement) 1F else -1F
}

internal fun ServerPlayer.yMovement(): Float = if (isJump()) 1F else if (lastClientInput.shift) -1F else 0F

internal fun ServerPlayer.zMovement(): Float {
    val forwardMovement: Boolean = lastClientInput.forward()
    val backwardMovement: Boolean = lastClientInput.backward()
    return if (forwardMovement == backwardMovement) 0F else if (forwardMovement) 1F else -1F
}

internal fun ServerPlayer.isJump() = lastClientInput.jump()

internal val Entity.isFlying: Boolean
    get() = when (this) {
        is FlyingAnimal -> isFlying
        is Mob -> isNoAi
        is Player -> abilities.flying
        is LivingEntity -> isFallFlying
        else -> false
    }

internal val CraftEntity.vanillaEntity: Entity
    get() = if (BetterModelBukkit.IS_PAPER) handleRaw else handle

internal fun Entity.moveTo(vec: Vec3) = snapTo(vec)
internal fun Entity.moveTo(x: Double, y: Double, z: Double, yaw: Float, pitch: Float) = snapTo(x, y, z, yaw, pitch)

internal inline fun <T> useByteBuf(block: (FriendlyByteBuf) -> T): T {
    val buffer = FriendlyByteBuf(Unpooled.buffer())
    return try {
        block(buffer)
    } finally {
        buffer.release()
    }
}

internal fun EntityTrackerRegistry.entityFlag(uuid: UUID, byte: Byte): Byte {
    var b = byte.toInt()
    val hideOption = hideOption(uuid)
    if (hideOption.fire()) b = b and 1.inv()
    if (hideOption.visibility()) b = b or (1 shl 5)
    if (hideOption.glowing()) b = b and (1 shl 6).inv()
    return b.toByte()
}

internal fun Vector3f.toVanilla() = Vec3(x.toDouble(), y.toDouble(), z.toDouble())
internal fun Vec3.toBukkit() = Vector3f(x.toFloat(), y.toFloat(), z.toFloat())

internal inline fun LivingEntity.toEquipmentPacket(mapper: (EquipmentSlot) -> ItemStack? = { getItemBySlot(it).takeUnless { item -> item.isEmpty } }): ClientboundSetEquipmentPacket? {
    val equip = EquipmentSlot.entries.mapNotNull {
        mapper(it)?.let { item -> com.mojang.datafixers.util.Pair.of(it, item) }
    }
    return if (equip.isNotEmpty()) ClientboundSetEquipmentPacket(id, equip) else null
}
internal fun LivingEntity.toEmptyEquipmentPacket() = toEquipmentPacket { ItemStack.EMPTY }

internal val Player.hotbarSlot get() = inventory.selectedSlot + 36
internal val PLAYER_EQUIPMENT_SLOT = IntSet.of(45, 5, 6, 7, 8)
internal fun ClientboundContainerSetSlotPacket.isEquipment(player: Player) = containerId == 0 && (PLAYER_EQUIPMENT_SLOT.contains(slot) || slot == player.hotbarSlot)

internal fun Entity.toFakeAddPacket() = ClientboundAddEntityPacket(
    id,
    uuid,
    x,
    y,
    z,
    xRot,
    yRot,
    EntityType.ITEM_DISPLAY,
    0,
    deltaMovement,
    yHeadRot.toDouble()
)

internal fun Player.toCustomisation() = entityData.get(Player.DATA_PLAYER_MODE_CUSTOMISATION).toInt()

internal fun VanillaComponent.asAdventure() = if (BetterModelBukkit.IS_PAPER) {
    PaperAdventure.asAdventure(this)
} else {
    GsonComponentSerializer.gson().deserialize(CraftChatMessage.toJSON(this))
}

internal fun AdventureComponent.asVanilla() = if (BetterModelBukkit.IS_PAPER) {
    PaperAdventure.asVanilla(this)
} else {
    CraftChatMessage.fromJSON(GsonComponentSerializer.gson().serialize(this))
}
