/*
 * This source file is part of BetterModel.
 * Copyright (c) 2026 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.bukkit.nms.v1_21_R3

import kr.toxicity.model.api.bukkit.entity.BaseBukkitEntity
import kr.toxicity.model.api.platform.PlatformEntity
import kr.toxicity.model.api.platform.PlatformLocation
import kr.toxicity.model.api.platform.PlatformPlayer
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.effect.MobEffects
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.entity.ai.attributes.Attributes
import org.bukkit.craftbukkit.entity.CraftEntity
import org.bukkit.persistence.PersistentDataHolder
import org.joml.Vector3f
import java.util.*
import java.util.stream.Stream

internal data class BaseEntityImpl(
    private val delegate: CraftEntity
) : BaseBukkitEntity, PersistentDataHolder by delegate {
    override fun customName(): AdventureComponent? = handle().run {
        if (this is ServerPlayer) (customName ?: name).asAdventure() else customName?.asAdventure()?.takeIf {
            isCustomNameVisible
        }
    }

    override fun entity(): org.bukkit.entity.Entity = delegate
    override fun handle(): Entity = delegate.vanillaEntity
    override fun uuid(): UUID = delegate.uniqueId
    override fun id(): Int = handle().id
    override fun dead(): Boolean = (handle() as? LivingEntity)?.isDeadOrDying == true || handle().removalReason != null || !handle().valid
    override fun invisible(): Boolean = handle().isInvisible || (handle() as? LivingEntity)?.hasEffect(MobEffects.INVISIBILITY) == true
    override fun glow(): Boolean = handle().isCurrentlyGlowing

    override fun onWalk(): Boolean {
        return handle().isWalking()
    }

    override fun scale(): Double {
        val handle = handle()
        return if (handle is LivingEntity) handle.scale.toDouble() else 1.0
    }

    override fun pitch(): Float = handle().xRot
    override fun ground(): Boolean = handle().onGround()
    override fun bodyYaw(): Float = handle().let { if (it is LivingEntity) it.yBodyRot else it.yRot }
    override fun yaw(): Float = handle().yRot
    override fun headYaw(): Float = handle().let { if (it is LivingEntity) it.yHeadRot else it.yRot }
    override fun fly(): Boolean = handle().isFlying

    override fun damageTick(): Float {
        val handle = handle()
        if (handle !is LivingEntity) return 0F
        val duration = handle.invulnerableDuration.toFloat()
        if (duration <= 0F) return 0F
        val knockBack = 1 - (handle.getAttribute(Attributes.KNOCKBACK_RESISTANCE)?.value?.toFloat() ?: 0F)
        return handle.invulnerableTime.toFloat() / duration * knockBack
    }

    override fun walkSpeed(): Float {
        val handle = handle()
        if (handle !is LivingEntity) return 0F
        if (!handle.onGround) return 1F
        val speed = handle.getEffect(MobEffects.MOVEMENT_SPEED)?.amplifier ?: 0
        val slow = handle.getEffect(MobEffects.MOVEMENT_SLOWDOWN)?.amplifier ?: 0
        return (1F + (speed - slow) * 0.2F)
            .coerceAtLeast(0.2F)
            .coerceAtMost(2F)
    }

    override fun passengerPosition(dest: Vector3f): Vector3f {
        return handle().passengerPosition(dest)
    }

    override fun platform(): PlatformEntity = delegate.wrap()
    override fun trackedBy(): Stream<PlatformPlayer> = delegate.trackedBy.stream().map { it.wrap() }
    override fun location(): PlatformLocation = delegate.location.wrap()
}
