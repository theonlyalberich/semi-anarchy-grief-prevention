/*
 * This source file is part of BetterModel.
 * Copyright (c) 2025 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.api.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonParser;
import com.google.gson.annotations.SerializedName;
import com.google.gson.stream.JsonReader;
import kr.toxicity.model.api.BetterModel;
import kr.toxicity.model.api.BetterModelPlatform;
import kr.toxicity.model.api.version.MinecraftVersion;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.semver4j.Semver;

import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.function.Function;

/**
 * Http util
 */
@ApiStatus.Internal
public final class HttpUtil {

    private static final HttpClient CLIENT = HttpClient.newBuilder()
        .connectTimeout(Duration.of(5, ChronoUnit.SECONDS))
        .executor(Executors.newVirtualThreadPerTaskExecutor())
        .build();
    private static final Gson GSON = new GsonBuilder()
        .registerTypeAdapter(MinecraftVersion.class, (JsonDeserializer<MinecraftVersion>) (json, _, _) -> MinecraftVersion.parse(json.getAsString()))
        .registerTypeAdapter(Semver.class, (JsonDeserializer<Semver>) (json, _, _) -> Semver.coerce(json.getAsString()))
        .create();

    /**
     * No initializer
     */
    private HttpUtil() {
        throw new RuntimeException();
    }

    /**
     * Searches BetterModel's latest version
     * @return latest version
     */
    public static @NotNull LatestVersion latest() {
        return latest(BetterModel.platform().version());
    }

    /**
     * Searches BetterModel's latest version compatible with current server
     * @param version server version
     * @return latest version
     */
    public static @NotNull LatestVersion latest(@NotNull MinecraftVersion version) {
        return client(client -> {
            try (var stream = client.send(HttpRequest.newBuilder()
                .GET()
                .uri(URI.create("https://api.modrinth.com/v2/project/bettermodel/version"))
                .build(), HttpResponse.BodyHandlers.ofInputStream()).body();
                 var reader = new InputStreamReader(stream);
                 var jsonReader = new JsonReader(reader)
            ) {
                return latestOf(JsonParser.parseReader(jsonReader)
                    .getAsJsonArray()
                    .asList()
                    .stream()
                    .map(e -> GSON.fromJson(e, PluginVersion.class))
                    .filter(PluginVersion::isSamePlatform)
                    .filter(v -> v.versions.contains(version))
                    .sorted(Comparator.comparing((PluginVersion v) -> v.versionNumber).reversed())
                    .toList());
            }
        }).orElse(e -> {
            LogUtil.handleException("Unable to get BetterModel's version info.", e);
            return new LatestVersion(null, null);
        });
    }

    /**
     * Gets the latest version from a version list
     * @param versions versions
     * @return latest version
     */
    public static @NotNull LatestVersion latestOf(@NotNull List<PluginVersion> versions) {
        PluginVersion release = null, snapshot = null;
        for (PluginVersion version : versions) {
            if (version.versionType.equals("release")) {
                if (release == null) release = version;
            } else if (snapshot == null) snapshot = version;
            if (release != null && snapshot != null) break;
        }
        return new LatestVersion(release, snapshot);
    }

    /**
     * Latest version
     * @param release release
     * @param snapshot snapshot
     */
    public record LatestVersion(@Nullable PluginVersion release, @Nullable PluginVersion snapshot) {
    }

    /**
     * Plugin version
     * @param id id
     * @param versionNumber number
     * @param versionType type
     * @param versions game versions
     * @param loaders loaders
     */
    public record PluginVersion(
        @NotNull String id,
        @NotNull @SerializedName("version_number") Semver versionNumber,
        @NotNull @SerializedName("version_type") String versionType,
        @NotNull @SerializedName("game_versions") Set<MinecraftVersion> versions,
        @NotNull Set<BetterModelPlatform.JarType> loaders
    ) {
        /**
         * Creates a text component with URL
         * @return text component
         */
        public @NotNull Component toURLComponent() {
            var url = "https://modrinth.com/plugin/bettermodel/version/" + id;
            return Component.text(builder -> builder
                .content(versionNumber.getVersion())
                .color(NamedTextColor.AQUA)
                .hoverEvent(
                    HoverEvent.showText(Component.text(hover -> hover
                        .append(Component.text(url).color(NamedTextColor.DARK_AQUA))
                        .appendNewline()
                        .append(Component.text("Click to open link.")))
                    )
                )
                .clickEvent(ClickEvent.openUrl(url))
            );
        }

        /**
         * Checks this version is same platform with running platform
         * @return is same platform
         */
        public boolean isSamePlatform() {
            return loaders.contains(BetterModel.platform().jarType());
        }
    }

    /**
     * Uses http client
     * @param consumer consumer
     * @return result
     * @param <T> type
     */
    public static <T> @NotNull Result<T> client(@NotNull HttpClientConsumer<T> consumer) {
        try {
            return new Result.Success<>(consumer.accept(CLIENT));
        } catch (Exception e) {
            return new Result.Failure<>(e);
        }
    }

    /**
     * http result
     * @param <T> type
     */
    public sealed interface Result<T> {

        /**
         * Gets the value or handle exception
         * @param function exception handler
         * @return value
         */
        default @NotNull T orElse(@NotNull Function<Exception, T> function) {
            return switch (this) {
                case Failure<T> failure -> function.apply(failure.exception);
                case Success<T> success -> success.result;
            };
        }

        /**
         * Success
         * @param result result value
         * @param <T> type
         */
        record Success<T>(@NotNull T result) implements Result<T> {}

        /**
         * Failure
         * @param exception exception
         * @param <T> type
         */
        record Failure<T>(@NotNull Exception exception) implements Result<T> {}
    }

    /**
     * Http client consumer
     * @param <T> type
     */
    @FunctionalInterface
    public interface HttpClientConsumer<T> {
        /**
         * Accepts a task with an http client
         * @param client client
         * @return value
         * @throws Exception exception
         */
        @NotNull T accept(@NotNull HttpClient client) throws Exception;
    }
}
