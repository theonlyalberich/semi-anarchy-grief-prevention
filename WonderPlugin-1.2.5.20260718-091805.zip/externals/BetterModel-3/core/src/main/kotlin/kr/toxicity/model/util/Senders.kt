/*
 * This source file is part of BetterModel.
 * Copyright (c) 2025 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.util

import net.kyori.adventure.audience.Audience
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.ComponentLike
import net.kyori.adventure.text.TextComponent
import net.kyori.adventure.text.event.HoverEvent
import net.kyori.adventure.text.format.NamedTextColor
import net.kyori.adventure.text.format.TextColor
import net.kyori.adventure.text.format.TextDecoration

private val INFO = " [!] ".toComponent {
    decorate(TextDecoration.BOLD).color(NamedTextColor.GREEN)
}
private val WARN = " [!] ".toComponent {
    decorate(TextDecoration.BOLD).color(NamedTextColor.RED)
}

fun String.toComponent(builder: TextComponent.Builder.() -> Unit = {}) = componentOf(this, builder)
fun String.toComponent(color: TextColor) = componentOf(this) {
    color(color)
}

fun spaceComponentOf() = Component.space()
fun emptyComponentOf() = Component.empty()
fun lineComponentOf() = Component.newline()
fun componentOf(vararg like: ComponentLike) = componentOf {
    append(*like)
}
fun componentWithLineOf(vararg like: ComponentLike) = componentOf {
    like.forEachIndexed { i, l ->
        append(l)
        if (i < like.lastIndex) append(lineComponentOf())
    }
}
fun componentOf(content: String, builder: TextComponent.Builder.() -> Unit) = componentOf {
    content(content)
    builder()
}
fun componentOf(builder: TextComponent.Builder.() -> Unit) = Component.text { it.builder() }
fun ComponentLike.toHoverEvent() = HoverEvent.showText(this)

fun Audience.info(message: String) = info(message.toComponent())
fun Audience.warn(message: String) = warn(message.toComponent())
fun Audience.infoNotNull(vararg messages: ComponentLike?): Unit = info(*messages.filterNotNull().ifEmpty {
    return
}.toTypedArray())
fun Audience.info(vararg messages: ComponentLike) = sendMessage(componentWithLineOf(*messages.map { componentOf(INFO, it) }.toTypedArray()))
fun Audience.warn(vararg messages: ComponentLike) = sendMessage(componentWithLineOf(*messages.map { componentOf(WARN, it) }.toTypedArray()))
fun Audience.info(message: ComponentLike) = sendMessage(componentOf(INFO, message))
fun Audience.warn(message: ComponentLike) = sendMessage(componentOf(WARN, message))
