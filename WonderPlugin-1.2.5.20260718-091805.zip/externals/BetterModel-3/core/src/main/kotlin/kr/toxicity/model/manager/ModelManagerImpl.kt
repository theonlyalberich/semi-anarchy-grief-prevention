/*
 * This source file is part of BetterModel.
 * Copyright (c) 2024 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.manager

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kr.toxicity.model.api.bone.BoneItemMapper
import kr.toxicity.model.api.data.ModelAsset
import kr.toxicity.model.api.data.blueprint.BlueprintElement
import kr.toxicity.model.api.data.blueprint.BlueprintJson
import kr.toxicity.model.api.data.blueprint.ModelBlueprint
import kr.toxicity.model.api.data.renderer.ModelRenderer
import kr.toxicity.model.api.data.renderer.RendererGroup
import kr.toxicity.model.api.event.ModelAssetsEvent
import kr.toxicity.model.api.event.ModelImportedEvent
import kr.toxicity.model.api.manager.ModelManager
import kr.toxicity.model.api.pack.PackBuilder
import kr.toxicity.model.api.pack.PackZipper
import kr.toxicity.model.api.platform.PlatformNamespace
import kr.toxicity.model.util.*
import net.kyori.adventure.text.format.NamedTextColor.*
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.io.path.extension

object ModelManagerImpl : ModelManager, GlobalManager {

    private lateinit var itemModelNamespace: PlatformNamespace
    private val generalModelMap = addressingMapOf<String, ModelRenderer>()
    private val generalModelView = generalModelMap.toImmutableView()
    private val playerModelMap = addressingMapOf<String, ModelRenderer>()
    private val playerModelView = playerModelMap.toImmutableView()
    private val modelExtensions = setOf("bbmodel", "ajmodel")

    private fun importModels(
        type: ModelRenderer.Type,
        pipeline: ReloadPipeline,
        dir: File
    ): Sequence<ImportedModel> {
        val targetAssets = ModelAssetsEvent(type, dir.fileTrees().use { stream ->
            stream.filter { it.extension.lowercase() in modelExtensions }
                .map(ModelAsset::of)
                .toMutableSet()
        }).apply { call() }
            .assets
            .ifEmpty { return emptySequence() }
            .toList()
        val modelFileMap = ConcurrentHashMap<String, Pair<ModelAsset, ModelBlueprint>>(targetAssets.size)
        val typeName = type.name.lowercase()
        pipeline.apply {
            status = "Importing $typeName models..."
            goal = targetAssets.size
        }.forEachParallel(targetAssets, ModelAsset::sizeAssume) {
            val index = pipeline.progress(it.name)
            val load = it.toTexturedModel() ?: return@forEachParallel
            modelFileMap.compute(load.name) { _, v ->
                if (v != null) {
                    // A model with the same name already exists from a different file
                    warn(
                        "Duplicate $typeName model name '${load.name}'.".toComponent(),
                        "Duplicated file: $it".toComponent(RED),
                        "And: ${v.first}".toComponent(RED)
                    )
                    if (v.first < it) return@compute v
                }
                debugPack {
                    componentOf(
                        "$typeName model file successfully loaded: ".toComponent(),
                        it.toString().toComponent(GREEN),
                        " ($index/${pipeline.goal})".toComponent(DARK_GRAY)
                    )
                }
                it to load
            }
        }
        return modelFileMap.values
            .asSequence()
            .sortedBy { it.first }
            .map {
                ImportedModel(
                    it.first.sizeAssume - it.second.textures.sumOf { tex -> tex.image.size },
                    type,
                    it.second
                )
            }
    }

    private fun loadModels(pipeline: ReloadPipeline, zipper: PackZipper) {
        ModelPipeline(zipper).use {
            if (CONFIG.module().model) it.addModelTo(
                generalModelMap,
                importModels(ModelRenderer.Type.GENERAL, pipeline, DATA_FOLDER.getOrCreateDirectory("models") { folder ->
                    File(DATA_FOLDER.parent, "ModelEngine/blueprints")
                        .takeIf(File::isDirectory)
                        ?.run {
                            copyRecursively(folder, overwrite = true)
                            info("ModelEngine's models are successfully migrated.".toComponent(GREEN))
                        } ?: run {
                        folder.addResource("demon_knight.bbmodel")
                        folder.addResource("blue_wizard.bbmodel")
                    }
                })
            )
            if (CONFIG.module().playerAnimation) it.addModelTo(
                playerModelMap,
                importModels(ModelRenderer.Type.PLAYER, pipeline, DATA_FOLDER.getOrCreateDirectory("players") { folder ->
                    folder.addResource("steve.bbmodel")
                })
            )
        }
    }

    private data class ImportedModel(
        val jsonSize: Long,
        val type: ModelRenderer.Type,
        val blueprint: ModelBlueprint
    )

    private class ModelPipeline(
        zipper: PackZipper
    ) : AutoCloseable {

        private var indexer = 1
        private var estimatedSize = 0L
        private val textures = zipper.assets().bettermodel().textures()

        private val modernModel = ModelBuilder(
            namespace = zipper.assets().obfuscate("modern_item"),
            builder = { zipper.assets().bettermodel().models().resolve(namespace) },
            available = true,
            onBuild = { blueprints, json, size ->
                entries += jsonObjectOf(
                    "threshold" to indexer,
                    "model" to blueprints.toModernJson(namespace, json)
                )
                blueprints.forEach { json ->
                    models.add(json.jsonName(), size / blueprints.size) {
                        json.buildJson().toByteArray()
                    }
                }
            },
            onClose = {
                zipper.assets().bettermodel().items().add("${CONFIG.itemNamespace()}.json", estimatedSize) {
                    jsonObjectOf("model" to jsonObjectOf(
                        "type" to "range_dispatch",
                        "property" to "custom_model_data",
                        "fallback" to jsonObjectOf(
                            "type" to "empty"
                        ),
                        "entries" to entries
                    )).toByteArray()
                }
            }
        )

        override fun close() {
            modernModel.close()
        }

        fun addModelTo(
            targetMap: MutableMap<String, ModelRenderer>,
            model: Sequence<ImportedModel>
        ) {
            model.forEach { addModelTo(targetMap, it) }
        }

        private fun addModelTo(
            targetMap: MutableMap<String, ModelRenderer>,
            importedModel: ImportedModel
        ) {
            val (size, type, blueprint) = importedModel
            val context = blueprint.context()
            targetMap[blueprint.name] = blueprint.toRenderer(type) render@ { group ->
                if (!context.canBeRendered()) return@render null
                modernModel.ifAvailable {
                    val json = group.buildModernJson(obfuscator, context)
                    val itemModel = group.buildMeshItemModel(context)
                    if (json != null || itemModel != null) {
                        build(json ?: emptyList(), itemModel, if (json != null) size / json.size else 0)
                        indexer++
                    } else null
                }
            }.apply {
                debugPack {
                    componentOf(
                        "This model was successfully imported: ".toComponent(),
                        blueprint.name.toComponent(GREEN)
                    )
                }
                callEvent { ModelImportedEvent(blueprint, this) }
            }
            context.buildImage(textures.obfuscator()).forEach { image ->
                textures.add(image.pngName(), image.estimatedSize()) {
                    image.toByteArray()
                }
                image.mcmeta()?.let { meta ->
                    textures.add(image.mcmetaName(), -1) {
                        meta.toByteArray()
                    }
                }
            }
            estimatedSize += size
        }

        inner class ModelBuilder(
            val namespace: String,
            val builder: ModelBuilder.() -> PackBuilder,
            private val available: Boolean,
            private val onBuild: ModelBuilder.(List<BlueprintJson>, JsonObject?, Long) -> Unit,
            private val onClose: ModelBuilder.() -> Unit
        ) : AutoCloseable {
            val entries = jsonArrayOf()
            val models = builder()
            val obfuscator = textures.obfuscator().withModels(models.obfuscator())

            inline fun <T> ifAvailable(block: ModelBuilder.() -> T): T? {
                return if (available) block() else null
            }

            fun build(list: List<BlueprintJson>, json: JsonObject?, size: Long) {
                onBuild(list, json, size)
            }

            override fun close() {
                ifAvailable {
                    if (!entries.isEmpty) onClose()
                }
            }
        }

        private fun List<BlueprintJson>.toModernJson(namespace: String, plus: JsonObject?) = if (size == 1) first().toModernJson(namespace) else jsonObjectOf(
            "type" to "composite",
            "models" to fold(JsonArray(size + if (plus != null) 1 else 0).apply {
                plus?.run(::add)
            }) { array, element -> array.apply { add(element.toModernJson(namespace)) } }
        )

        private fun BlueprintJson.toModernJson(namespace: String) = jsonObjectOf(
            "type" to "model",
            "model" to "${CONFIG.namespace()}:$namespace/$name",
            "tints" to jsonArrayOf(
                jsonObjectOf(
                    "type" to "custom_model_data",
                    "default" to 0xFFFFFF
                )
            )
        )

        private fun ModelBlueprint.toRenderer(type: ModelRenderer.Type, builder: (BlueprintElement.Group) -> Int?): ModelRenderer {
            fun <T> Collection<BlueprintElement>.toBoneMap(mapper: (BlueprintElement.Bone) -> T) = filterIsInstance<BlueprintElement.Bone>().let { bone ->
                bone.associateTo(sequencedAddressingMapOf(bone.size)) { it.name() to mapper(it) }
            }.toImmutableView()
            fun BlueprintElement.Bone.parse(): RendererGroup {
                if (this !is BlueprintElement.Group) return RendererGroup(1.0F, null, this, emptySequencedMap(), null)
                return RendererGroup(
                    scale(),
                    if (name.toItemMapper() !== BoneItemMapper.EMPTY) null else builder(this)?.let { i ->
                        CONFIG.item().get().modelData(i, itemModelNamespace)
                    },
                    this,
                    children.toBoneMap { it.parse() },
                    hitBox(),
                )
            }
            return ModelRenderer(
                name,
                type,
                elements.toBoneMap { it.parse() },
                animations
            )
        }
    }

    override fun start() {
    }

    override fun reload(pipeline: ReloadPipeline, zipper: PackZipper) {
        itemModelNamespace = PlatformNamespace(CONFIG.namespace(), CONFIG.itemNamespace())
        generalModelMap.clear()
        playerModelMap.clear()
        loadModels(pipeline, zipper)
    }

    override fun model(name: String): ModelRenderer? = generalModelView[name]
    override fun models(): Collection<ModelRenderer> = generalModelView.values
    override fun modelKeys(): Set<String> = generalModelView.keys
    override fun limb(name: String): ModelRenderer? = playerModelView[name]
    override fun limbs(): Collection<ModelRenderer> = playerModelView.values
    override fun limbKeys(): Set<String> = playerModelView.keys
}
